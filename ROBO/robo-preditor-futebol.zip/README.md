# Robô Preditor de Futebol

Um projeto simples com IA para prever resultados de jogos de futebol.